</div>
</body>
</html>

<script src="../JS/script.js"></script>