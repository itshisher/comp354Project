<?php
    include_once 'header.php';
?>

    <section class="index-intro">
        <h1>Welcome to the book shelf web app!</h1>
        <p>Here you can check our available books, read and put them in your shelves</p>
        <p>You can arrange your books and also will receive our recommendations!</p>

    </section>
    

<?php
    include_once 'footer.php';
?>