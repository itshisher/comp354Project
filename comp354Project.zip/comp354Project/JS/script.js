var btn = document.getElementById("home");
btn.addEventListener("click", function () {
  document.location.href = "../frontend/homeSorted.php";
});
