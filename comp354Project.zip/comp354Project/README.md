This is a Book-Project web app with shelves:<br>
&nbsp;&nbsp;&nbsp;Reading: Books that are currently being read<br>
&nbsp;&nbsp;&nbsp;Read: Books that are already read<br>
&nbsp;&nbsp;&nbsp;To Read: Books that will be read in the future<br>
&nbsp;&nbsp;&nbsp;Favorites: which contains all the books most liked by the user<br>
&nbsp;&nbsp;&nbsp;Recommendations: containing books recommended for the user
based on the user’s interest<br>

Created a local database called bookappdb with three tables (book, records, user)<br>
login, signup system are included<br>
Home page can show all books that exist in the database<br>
